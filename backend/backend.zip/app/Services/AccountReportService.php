<?php

namespace App\Services;

use App\Models\AccountTransactionDetail;
use App\Models\AccountType;
use App\Models\ChartOfAccount;
use App\Models\Customer;
use App\Models\CustomerTransaction;
use App\Models\IncomeExpenseTransaction;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\Supplier;
use App\Models\SupplierTransaction;
use App\Models\WorkOrder;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

/**
 * The payroll_software Account module's reports: the ledger reports (general
 * ledger, trial balance, profit & loss, balance sheet, cash transactions),
 * computed from the journal lines dated by their entry's date, the bank
 * reconciliation, and the supplier, customer, expense and sales/purchase
 * reports built from the sub-ledgers and documents.
 */
class AccountReportService
{
    /**
     * One account's lines between two dates, with the balance brought
     * forward and a running balance (debit minus credit, labelled Dr/Cr).
     *
     * @return array{account: array{id: int, name: string, account_number: ?string}, from_date: string, to_date: string, opening_balance: float, opening_balance_type: string, transactions: array<int, array<string, mixed>>, total_debit: float, total_credit: float, closing_balance: float, closing_balance_type: string}
     */
    public function generalLedger(ChartOfAccount $account, string $fromDate, string $toDate): array
    {
        $opening = $this->lines()
            ->where('account_transaction_details.chart_of_account_id', $account->id)
            ->where('account_transactions.date', '<', $fromDate)
            ->selectRaw('COALESCE(SUM(account_transaction_details.debit), 0) - COALESCE(SUM(account_transaction_details.credit), 0) as net')
            ->value('net');

        $balance = round((float) $opening, 2);
        $totalDebit = 0.0;
        $totalCredit = 0.0;

        $transactions = $this->lines()
            ->where('account_transaction_details.chart_of_account_id', $account->id)
            ->whereBetween('account_transactions.date', [$fromDate, $toDate])
            ->orderBy('account_transactions.date')
            ->orderBy('account_transaction_details.id')
            ->get([
                'account_transaction_details.id',
                'account_transaction_details.account_transaction_id',
                'account_transactions.date',
                'account_transactions.tr_no',
                'account_transactions.general_particular',
                'account_transaction_details.particular',
                'account_transaction_details.debit',
                'account_transaction_details.credit',
            ])
            ->map(function (AccountTransactionDetail $line) use (&$balance, &$totalDebit, &$totalCredit) {
                $debit = (float) $line->debit;
                $credit = (float) $line->credit;
                $balance = round($balance + $debit - $credit, 2);
                $totalDebit += $debit;
                $totalCredit += $credit;

                return [
                    'id' => $line->id,
                    'account_transaction_id' => $line->account_transaction_id,
                    'date' => substr((string) $line->getRawOriginal('date'), 0, 10),
                    'tr_no' => $line->tr_no,
                    'general_particular' => $line->general_particular,
                    'particular' => $line->particular,
                    'debit' => $debit,
                    'credit' => $credit,
                    'balance' => abs($balance),
                    'balance_type' => $this->side($balance),
                ];
            })
            ->all();

        return [
            'account' => ['id' => $account->id, 'name' => $account->name, 'account_number' => $account->account_number],
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'opening_balance' => abs((float) $opening),
            'opening_balance_type' => $this->side((float) $opening),
            'transactions' => $transactions,
            'total_debit' => round($totalDebit, 2),
            'total_credit' => round($totalCredit, 2),
            'closing_balance' => abs($balance),
            'closing_balance_type' => $this->side($balance),
        ];
    }

    /**
     * A cash/bank account's book balance on the statement date reconciled
     * to the bank: deposits not yet cleared are taken off and payments not
     * yet cleared are added back, giving the balance the bank should show.
     * A line is outstanding when it has no cleared date or was cleared after
     * the statement date. The rows are the period's lines (from `from_date`)
     * plus any older line still outstanding, so each can be ticked off.
     *
     * @return array{account: array{id: int, name: string, account_number: ?string}, from_date: ?string, to_date: string, transactions: array<int, array<string, mixed>>, book_balance: float, outstanding_deposits: float, outstanding_payments: float, adjusted_balance: float, statement_balance: ?float, difference: ?float, is_reconciled: ?bool}
     */
    public function bankReconciliation(ChartOfAccount $account, ?string $fromDate, string $toDate, ?float $statementBalance): array
    {
        $isOutstanding = fn (Builder $query) => $query->where(fn (Builder $query) => $query
            ->whereNull('account_transaction_details.cleared_date')
            ->orWhereDate('account_transaction_details.cleared_date', '>', $toDate));

        $accountLines = fn () => $this->lines()
            ->where('account_transaction_details.chart_of_account_id', $account->id)
            ->whereDate('account_transactions.date', '<=', $toDate);

        $bookBalance = round((float) $accountLines()
            ->selectRaw('COALESCE(SUM(account_transaction_details.debit), 0) - COALESCE(SUM(account_transaction_details.credit), 0) as net')
            ->value('net'), 2);

        $outstanding = $isOutstanding($accountLines())
            ->selectRaw('COALESCE(SUM(account_transaction_details.debit), 0) as deposits, COALESCE(SUM(account_transaction_details.credit), 0) as payments')
            ->first();
        $outstandingDeposits = round((float) $outstanding->deposits, 2);
        $outstandingPayments = round((float) $outstanding->payments, 2);

        $transactions = $accountLines()
            ->where(fn (Builder $query) => $fromDate
                ? $isOutstanding($query)->orWhereDate('account_transactions.date', '>=', $fromDate)
                : $isOutstanding($query))
            ->orderBy('account_transactions.date')
            ->orderBy('account_transaction_details.id')
            ->get([
                'account_transaction_details.id',
                'account_transaction_details.account_transaction_id',
                'account_transactions.date',
                'account_transactions.tr_no',
                'account_transactions.general_particular',
                'account_transaction_details.particular',
                'account_transaction_details.debit',
                'account_transaction_details.credit',
                'account_transaction_details.cleared_date',
            ])
            ->map(fn (AccountTransactionDetail $line) => [
                'id' => $line->id,
                'account_transaction_id' => $line->account_transaction_id,
                'date' => substr((string) $line->getRawOriginal('date'), 0, 10),
                'tr_no' => $line->tr_no,
                'general_particular' => $line->general_particular,
                'particular' => $line->particular,
                'debit' => (float) $line->debit,
                'credit' => (float) $line->credit,
                'cleared_date' => $line->cleared_date?->toDateString(),
                'is_cleared' => $line->cleared_date !== null && $line->cleared_date->toDateString() <= $toDate,
            ])
            ->all();

        $adjustedBalance = round($bookBalance - $outstandingDeposits + $outstandingPayments, 2);
        $difference = $statementBalance === null ? null : round($statementBalance - $adjustedBalance, 2);

        return [
            'account' => ['id' => $account->id, 'name' => $account->name, 'account_number' => $account->account_number],
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'transactions' => $transactions,
            'book_balance' => $bookBalance,
            'outstanding_deposits' => $outstandingDeposits,
            'outstanding_payments' => $outstandingPayments,
            'adjusted_balance' => $adjustedBalance,
            'statement_balance' => $statementBalance,
            'difference' => $difference,
            'is_reconciled' => $difference === null ? null : $difference === 0.0,
        ];
    }

    /**
     * Mark an account's lines as cleared on the bank statement on a date, or
     * clear that mark when the date is null. A line cannot clear before its
     * entry's date.
     *
     * @param  array<int, int>  $lineIds
     *
     * @throws ValidationException
     */
    public function markCleared(ChartOfAccount $account, array $lineIds, ?string $clearedDate): int
    {
        $lines = $this->lines()
            ->where('account_transaction_details.chart_of_account_id', $account->id)
            ->whereIn('account_transaction_details.id', $lineIds);

        if ((clone $lines)->count() !== count(array_unique($lineIds))) {
            throw ValidationException::withMessages(['line_ids' => __('Some of the selected lines do not belong to this account.')]);
        }

        if ($clearedDate && (clone $lines)->whereDate('account_transactions.date', '>', $clearedDate)->exists()) {
            throw ValidationException::withMessages(['cleared_date' => __('A line cannot be cleared before its entry date.')]);
        }

        return AccountTransactionDetail::query()->whereIn('id', $lineIds)->update(['cleared_date' => $clearedDate]);
    }

    /**
     * Every open account's balance on its debit or credit side. "as_of_date"
     * sums everything up to `to_date`; "as_of_period" also splits out the
     * opening balance before `from_date` and the movement within the period.
     * As in the payroll module, the totals are of the balances shown in the
     * debit/credit columns (the period columns for "as_of_period").
     *
     * @return array{report_type: string, from_date: string, to_date: string, accounts: array<int, array<string, mixed>>, total_debit: float, total_credit: float}
     */
    public function trialBalance(string $fromDate, string $toDate, string $reportType): array
    {
        $accounts = ChartOfAccount::query()->where('is_closed', false)->orderBy('account_number')->orderBy('id')->get();

        $closing = $this->netByAccount(fn (Builder $query) => $query->where('account_transactions.date', '<=', $toDate));
        $opening = $reportType === 'as_of_period'
            ? $this->netByAccount(fn (Builder $query) => $query->where('account_transactions.date', '<', $fromDate))
            : collect();
        $period = $reportType === 'as_of_period'
            ? $this->netByAccount(fn (Builder $query) => $query->whereBetween('account_transactions.date', [$fromDate, $toDate]))
            : $closing;

        $rows = $accounts->map(function (ChartOfAccount $account) use ($reportType, $opening, $period, $closing) {
            $row = [
                'account_id' => $account->id,
                'account_no' => $account->account_number,
                'account_name' => $account->name,
                ...$this->columns((float) ($period[$account->id] ?? 0)),
            ];

            if ($reportType === 'as_of_period') {
                $row = [
                    ...$row,
                    ...$this->columns((float) ($opening[$account->id] ?? 0), 'opening_'),
                    ...$this->columns((float) ($closing[$account->id] ?? 0), 'closing_'),
                ];
            }

            return $row;
        });

        return [
            'report_type' => $reportType,
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'accounts' => $rows->values()->all(),
            'total_debit' => round($rows->sum('debit'), 2),
            'total_credit' => round($rows->sum('credit'), 2),
        ];
    }

    /**
     * Revenue (credit minus debit) less the cost of goods sold, giving the
     * gross profit, less expenses (debit minus credit).
     *
     * Product purchases are debited to Inventory/Stock, an asset, so they
     * never reach the expense accounts. Their cost comes in as the cost of
     * goods sold: opening stock + the period's net purchases into Inventory
     * (and its sub-accounts) − closing stock. The stock values are counted,
     * not kept by the ledger, so they are entered for the report; left at
     * zero, everything bought in the period counts as sold.
     *
     * @return array{total_revenue: float, opening_stock: float, purchases: float, closing_stock: float, cost_of_goods_sold: float, gross_profit: float, total_expense: float, profit_or_loss: float, result: string}
     */
    public function profitAndLoss(?string $fromDate = null, ?string $toDate = null, float $openingStock = 0, float $closingStock = 0): array
    {
        $revenue = -$this->netOfType(AccountType::REVENUE, $fromDate, $toDate);
        $purchases = $this->inventoryPurchases($fromDate, $toDate);
        $costOfGoodsSold = round($openingStock + $purchases - $closingStock, 2);
        $grossProfit = round($revenue - $costOfGoodsSold, 2);
        $expense = $this->netOfType(AccountType::EXPENSE, $fromDate, $toDate);
        $profitOrLoss = round($grossProfit - $expense, 2);

        $result = match (true) {
            $profitOrLoss > 0 => 'Profit: '.number_format($profitOrLoss, 2),
            $profitOrLoss < 0 => 'Loss: '.number_format(abs($profitOrLoss), 2),
            default => 'Break-Even: No profit, no loss.',
        };

        return [
            'total_revenue' => $revenue,
            'opening_stock' => round($openingStock, 2),
            'purchases' => $purchases,
            'closing_stock' => round($closingStock, 2),
            'cost_of_goods_sold' => $costOfGoodsSold,
            'gross_profit' => $grossProfit,
            'total_expense' => $expense,
            'profit_or_loss' => $profitOrLoss,
            'result' => $result,
        ];
    }

    /**
     * Debit minus credit posted to Inventory/Stock and its sub-accounts in
     * the period: what was bought into stock, less any returns.
     */
    private function inventoryPurchases(?string $fromDate, ?string $toDate): float
    {
        $accountIds = $this->accountTree(LedgerPostingService::INVENTORY_NUMBER)->modelKeys();

        if (! $accountIds) {
            return 0.0;
        }

        $net = $this->lines()
            ->whereIn('account_transaction_details.chart_of_account_id', $accountIds)
            ->when($fromDate, fn (Builder $query) => $query->where('account_transactions.date', '>=', $fromDate))
            ->when($toDate, fn (Builder $query) => $query->where('account_transactions.date', '<=', $toDate))
            ->selectRaw('COALESCE(SUM(account_transaction_details.debit), 0) - COALESCE(SUM(account_transaction_details.credit), 0) as net')
            ->value('net');

        return round((float) $net, 2);
    }

    /**
     * Headline figures for the accounting dashboard: sales and purchases
     * (net totals, optionally within a date range), and the current
     * receivable, payable and bank balances from the ledger. The bank balance
     * covers the Bank Accounts account and every account created under it.
     *
     * @return array{from_date: ?string, to_date: ?string, total_sales: float, total_purchase: float, total_receivable: float, total_payable: float, bank_balance: float, banks: array<int, array{id: int, name: string, account_number: ?string, balance: float}>}
     */
    public function dashboardSummary(?string $fromDate = null, ?string $toDate = null): array
    {
        $totalSales = Sale::query()
            ->when($fromDate, fn ($query) => $query->whereDate('issue_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('issue_date', '<=', $toDate))
            ->sum('net_total');

        $totalPurchase = Purchase::query()
            ->when($fromDate, fn ($query) => $query->whereDate('purchase_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('purchase_date', '<=', $toDate))
            ->sum('net_total');

        $receivableId = ChartOfAccount::query()->where('account_number', LedgerPostingService::ACCOUNTS_RECEIVABLE_NUMBER)->value('id');
        $payableId = ChartOfAccount::query()->where('account_number', LedgerPostingService::ACCOUNTS_PAYABLE_NUMBER)->value('id');
        $bankAccounts = $this->bankAccounts();

        $balances = $this->netByAccount(fn (Builder $query) => $query->whereIn(
            'account_transaction_details.chart_of_account_id',
            array_filter([$receivableId, $payableId, ...$bankAccounts->modelKeys()]),
        ));

        $banks = $bankAccounts->map(fn (ChartOfAccount $account) => [
            'id' => $account->id,
            'name' => $account->name,
            'account_number' => $account->account_number,
            'balance' => (float) ($balances[$account->id] ?? 0),
        ]);

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'total_sales' => round((float) $totalSales, 2),
            'total_purchase' => round((float) $totalPurchase, 2),
            'total_receivable' => (float) ($balances[$receivableId] ?? 0),
            'total_payable' => -(float) ($balances[$payableId] ?? 0),
            'bank_balance' => round($banks->sum('balance'), 2),
            'banks' => $banks->values()->all(),
        ];
    }

    /**
     * The Bank Accounts account and all of its descendants.
     *
     * @return EloquentCollection<int, ChartOfAccount>
     */
    private function bankAccounts(): EloquentCollection
    {
        return $this->accountTree(LedgerPostingService::BANK_ACCOUNTS_NUMBER);
    }

    /**
     * An account and all of its descendants.
     *
     * @return EloquentCollection<int, ChartOfAccount>
     */
    private function accountTree(string $accountNumber): EloquentCollection
    {
        $accounts = ChartOfAccount::query()->where('account_number', $accountNumber)->get(['id', 'name', 'account_number']);
        $parentIds = $accounts->modelKeys();

        while ($parentIds) {
            $children = ChartOfAccount::query()->whereIn('parent_id', $parentIds)->get(['id', 'name', 'account_number']);
            $accounts = $accounts->concat($children);
            $parentIds = $children->modelKeys();
        }

        return $accounts;
    }

    /**
     * Assets (debit minus credit) against liabilities and owner's equity
     * (credit minus debit), as the payroll module's balance sheet sums them.
     *
     * @return array{total_assets: float, total_liabilities: float, total_equity: float, is_balanced: bool}
     */
    public function balanceSheet(?string $toDate = null): array
    {
        $assets = $this->netOfType(AccountType::ASSET, null, $toDate);
        $liabilities = -$this->netOfType(AccountType::LIABILITY, null, $toDate);
        $equity = -$this->netOfType(AccountType::OWNER_EQUITY, null, $toDate);

        return [
            'total_assets' => $assets,
            'total_liabilities' => $liabilities,
            'total_equity' => $equity,
            'is_balanced' => round($assets, 2) === round($liabilities + $equity, 2),
        ];
    }

    /**
     * The payroll module's Supplier Report: selected suppliers' (all when
     * none are selected) ledger entries in a date range, with the balance
     * brought forward and a running due. A credit (purchase) raises what is
     * owed, a debit (payment) lowers it. Reversed entries are left out.
     *
     * @param  array<int, int>  $supplierIds
     * @return array{from_date: ?string, to_date: ?string, previous_balance: float, rows: array<int, array<string, mixed>>, total_amount: float, total_paid: float, total_due: float}
     */
    public function supplierStatement(array $supplierIds, ?string $fromDate, ?string $toDate): array
    {
        $opening = (float) Supplier::query()
            ->when($supplierIds, fn ($query) => $query->whereIn('id', $supplierIds))
            ->sum('opening_balance');

        return $this->partyStatement(
            SupplierTransaction::query()->with('supplier:id,name')->when($supplierIds, fn ($query) => $query->whereIn('supplier_id', $supplierIds)),
            $opening,
            'credit',
            fn (SupplierTransaction $row) => $row->supplier?->name,
            $fromDate,
            $toDate,
        );
    }

    /**
     * The payroll module's supplier outstanding balance report: every active
     * supplier's current balance.
     *
     * @return array{rows: array<int, array<string, mixed>>, total_opening_balance: float, total_current_balance: float}
     */
    public function supplierBalances(): array
    {
        $rows = Supplier::query()
            ->where('active_status', true)
            ->orderBy('name')
            ->get(['id', 'name', 'phone', 'email', 'contact_person', 'opening_balance', 'current_balance'])
            ->map(fn (Supplier $supplier) => [
                'id' => $supplier->id,
                'name' => $supplier->name,
                'phone' => $supplier->phone,
                'email' => $supplier->email,
                'contact_person' => $supplier->contact_person,
                'opening_balance' => (float) $supplier->opening_balance,
                'current_balance' => (float) $supplier->current_balance,
            ]);

        return [
            'rows' => $rows->all(),
            'total_opening_balance' => round($rows->sum('opening_balance'), 2),
            'total_current_balance' => round($rows->sum('current_balance'), 2),
        ];
    }

    /**
     * The payroll module's Sales Report (customer statement): selected
     * customers' (all when none are selected) ledger entries in a date range,
     * with the balance brought forward and a running due. A debit (invoice)
     * raises what the customer owes, a credit (payment) lowers it.
     *
     * @param  array<int, int>  $customerIds
     * @return array{from_date: ?string, to_date: ?string, previous_balance: float, rows: array<int, array<string, mixed>>, total_amount: float, total_paid: float, total_due: float}
     */
    public function customerStatement(array $customerIds, ?string $fromDate, ?string $toDate): array
    {
        $opening = (float) Customer::query()
            ->when($customerIds, fn ($query) => $query->whereIn('id', $customerIds))
            ->sum('opening_balance');

        return $this->partyStatement(
            CustomerTransaction::query()->with('customer:id,name')->when($customerIds, fn ($query) => $query->whereIn('customer_id', $customerIds)),
            $opening,
            'debit',
            fn (CustomerTransaction $row) => $row->customer?->name,
            $fromDate,
            $toDate,
        );
    }

    /**
     * The payroll module's Cash Transaction report: journal lines of the
     * selected accounts (all when none are selected) in a date range.
     *
     * @param  array<int, int>  $accountIds
     * @return array{from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, total_debit: float, total_credit: float}
     */
    public function cashTransactions(array $accountIds, ?string $fromDate, ?string $toDate): array
    {
        $rows = $this->lines()
            ->join('chart_of_accounts', 'chart_of_accounts.id', '=', 'account_transaction_details.chart_of_account_id')
            ->when($accountIds, fn (Builder $query) => $query->whereIn('account_transaction_details.chart_of_account_id', $accountIds))
            ->when($fromDate, fn (Builder $query) => $query->where('account_transactions.date', '>=', $fromDate))
            ->when($toDate, fn (Builder $query) => $query->where('account_transactions.date', '<=', $toDate))
            ->orderBy('account_transactions.date')
            ->orderBy('account_transaction_details.id')
            ->get([
                'account_transaction_details.id',
                'account_transactions.date',
                'account_transactions.tr_no',
                'chart_of_accounts.name as ledger_name',
                'chart_of_accounts.account_number',
                'account_transaction_details.particular',
                'account_transaction_details.debit',
                'account_transaction_details.credit',
            ])
            ->map(fn (AccountTransactionDetail $line) => [
                'id' => $line->id,
                'date' => substr((string) $line->getRawOriginal('date'), 0, 10),
                'tr_no' => $line->tr_no,
                'ledger_name' => $line->ledger_name,
                'account_number' => $line->account_number,
                'particular' => $line->particular,
                'debit' => (float) $line->debit,
                'credit' => (float) $line->credit,
            ]);

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'total_debit' => round($rows->sum('debit'), 2),
            'total_credit' => round($rows->sum('credit'), 2),
        ];
    }

    /**
     * The payroll module's Expense Details report: purchases (bills) whose
     * credit account is one of the selected accounts (all when none are
     * selected) in a purchase-date range, with VAT and net totals.
     *
     * @param  array<int, int>  $accountIds
     * @return array{from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, total_vat: float, total_net_amount: float}
     */
    public function expenseDetails(array $accountIds, ?string $fromDate, ?string $toDate): array
    {
        $rows = Purchase::query()
            ->with(['supplier:id,name', 'creditAccount:id,name', 'debitAccount:id,name'])
            ->when($accountIds, fn ($query) => $query->whereIn('credit_account_id', $accountIds))
            ->when($fromDate, fn ($query) => $query->whereDate('purchase_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('purchase_date', '<=', $toDate))
            ->orderBy('purchase_date')
            ->orderBy('id')
            ->get()
            ->map(fn (Purchase $purchase) => [
                'id' => $purchase->id,
                'ledger_name' => $purchase->creditAccount?->name,
                'debit_account_name' => $purchase->debitAccount?->name,
                'supplier_name' => $purchase->supplier?->name,
                'purchase_type' => $purchase->purchase_type,
                'invoice_number' => $purchase->invoice_number,
                'purchase_date' => $purchase->purchase_date?->toDateString(),
                'inserted_date' => $purchase->created_at?->toDateString(),
                'notes' => $purchase->notes,
                'vat_amount' => (float) $purchase->vat_amount,
                'net_total' => (float) $purchase->net_total,
            ]);

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'total_vat' => round($rows->sum('vat_amount'), 2),
            'total_net_amount' => round($rows->sum('net_total'), 2),
        ];
    }

    /**
     * The payroll module's Sales & Purchase Summary: sales (credit, by issue
     * date) and purchases (debit, by purchase date) in one date-ordered list
     * with a running balance of sales less purchases.
     *
     * @return array{from_date: string, to_date: string, rows: array<int, array<string, mixed>>, total_sales: float, total_purchase: float, balance: float}
     */
    public function salesPurchaseSummary(string $fromDate, string $toDate): array
    {
        $sales = Sale::query()
            ->whereBetween('issue_date', [$fromDate, $toDate])
            ->get(['id', 'invoice_number', 'issue_date', 'description', 'net_total'])
            ->map(fn (Sale $sale) => [
                'id' => $sale->id,
                'date' => $sale->issue_date?->toDateString(),
                'type' => 'Sale',
                'reference' => $sale->invoice_number,
                'description' => $sale->description,
                'debit' => 0.0,
                'credit' => (float) $sale->net_total,
            ]);

        $purchases = Purchase::query()
            ->whereBetween('purchase_date', [$fromDate, $toDate])
            ->get(['id', 'invoice_number', 'purchase_date', 'description', 'net_total'])
            ->map(fn (Purchase $purchase) => [
                'id' => $purchase->id,
                'date' => $purchase->purchase_date?->toDateString(),
                'type' => 'Purchase',
                'reference' => $purchase->invoice_number,
                'description' => $purchase->description,
                'debit' => (float) $purchase->net_total,
                'credit' => 0.0,
            ]);

        $balance = 0.0;
        $rows = $sales->concat($purchases)
            ->sortBy([['date', 'asc'], ['type', 'asc'], ['id', 'asc']])
            ->values()
            ->map(function (array $row) use (&$balance) {
                $balance = round($balance + $row['credit'] - $row['debit'], 2);

                return [...$row, 'balance' => $balance];
            });

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'total_sales' => round($sales->sum('credit'), 2),
            'total_purchase' => round($purchases->sum('debit'), 2),
            'balance' => $balance,
        ];
    }

    /**
     * The payroll module's sales report list: sales in an issue-date range,
     * optionally for one customer, with their amount totals.
     *
     * @return array{from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, totals: array<string, float>}
     */
    public function salesRegister(?int $customerId, ?string $fromDate, ?string $toDate): array
    {
        $rows = Sale::query()
            ->with('customer:id,name')
            ->when($customerId, fn ($query) => $query->where('customer_id', $customerId))
            ->when($fromDate, fn ($query) => $query->whereDate('issue_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('issue_date', '<=', $toDate))
            ->orderBy('issue_date')
            ->orderBy('id')
            ->get()
            ->map(fn (Sale $sale) => [
                'id' => $sale->id,
                'invoice_number' => $sale->invoice_number,
                'customer_name' => $sale->customer?->name,
                'issue_date' => $sale->issue_date?->toDateString(),
                'due_date' => $sale->due_date?->toDateString(),
                'total_amount' => (float) $sale->total_amount,
                'discount_amount' => (float) $sale->discount_amount,
                'vat_amount' => (float) $sale->vat_amount,
                'net_total' => (float) $sale->net_total,
                'paid_amount' => (float) $sale->paid_amount,
                'due_amount' => round((float) $sale->net_total - (float) $sale->paid_amount, 2),
            ]);

        $totals = [];
        foreach (['total_amount', 'discount_amount', 'vat_amount', 'net_total', 'paid_amount', 'due_amount'] as $column) {
            $totals[$column] = round($rows->sum($column), 2);
        }

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'totals' => $totals,
        ];
    }

    /**
     * Work orders (by issue date, customer and status) with what has been
     * billed (active invoices) and collected (active payments received)
     * against each, and the due left of the work order's amount, as the
     * work order screen computes its outstanding amount.
     *
     * @return array{from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, totals: array<string, float>}
     */
    public function workOrderCollections(?int $customerId, ?string $status, ?string $fromDate, ?string $toDate): array
    {
        $rows = WorkOrder::query()
            ->with('customer:id,name')
            ->withPaymentTotals()
            ->withSum(['transactions as billed_amount' => fn ($query) => $query->where('status', true)->where('transaction_type', 'Invoice')], 'debit')
            ->when($customerId, fn ($query) => $query->where('customer_id', $customerId))
            ->when($status, fn ($query) => $query->where('status', $status))
            ->when($fromDate, fn ($query) => $query->whereDate('issue_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('issue_date', '<=', $toDate))
            ->orderBy('issue_date')
            ->orderBy('id')
            ->get()
            ->map(fn (WorkOrder $workOrder) => [
                'id' => $workOrder->id,
                'work_order_no' => $workOrder->work_order_no,
                'work_title' => $workOrder->work_title,
                'customer_name' => $workOrder->customer?->name,
                'issue_date' => $workOrder->issue_date?->toDateString(),
                'status' => $workOrder->status,
                'total_amount' => (float) $workOrder->total_amount,
                'retention_amount' => $workOrder->retention_amount,
                'billed_amount' => round((float) $workOrder->billed_amount, 2),
                'collected_amount' => round((float) $workOrder->paid_amount, 2),
                'due_amount' => round((float) $workOrder->total_amount - (float) $workOrder->paid_amount, 2),
            ]);

        $totals = [];
        foreach (['total_amount', 'retention_amount', 'billed_amount', 'collected_amount', 'due_amount'] as $column) {
            $totals[$column] = round($rows->sum($column), 2);
        }

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'totals' => $totals,
        ];
    }

    /**
     * Each work order's sales against what was spent on it: the net total of
     * its sales and purchases, and its income and expense entries, dated in
     * the range when one is given, with the profit or loss they leave.
     *
     * @return array{from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, totals: array<string, float>}
     */
    public function workOrderProfitability(?int $customerId, ?string $status, ?string $fromDate, ?string $toDate): array
    {
        $inRange = fn (string $column, ?string $type = null) => fn ($query) => $query
            ->when($type, fn ($query) => $query->where('type', $type))
            ->when($fromDate, fn ($query) => $query->whereDate($column, '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate($column, '<=', $toDate));

        $rows = WorkOrder::query()
            ->with('customer:id,name')
            ->withSum(['sales as sales_amount' => $inRange('issue_date')], 'net_total')
            ->withSum(['purchases as purchase_amount' => $inRange('purchase_date')], 'net_total')
            ->withSum(['incomeExpenses as expense_amount' => $inRange('transaction_date', 'expense')], 'amount')
            ->withSum(['incomeExpenses as other_income_amount' => $inRange('transaction_date', 'income')], 'amount')
            ->when($customerId, fn ($query) => $query->where('customer_id', $customerId))
            ->when($status, fn ($query) => $query->where('status', $status))
            ->orderBy('issue_date')
            ->orderBy('id')
            ->get()
            ->map(function (WorkOrder $workOrder) {
                $income = (float) $workOrder->sales_amount + (float) $workOrder->other_income_amount;
                $cost = (float) $workOrder->purchase_amount + (float) $workOrder->expense_amount;

                return [
                    'id' => $workOrder->id,
                    'work_order_no' => $workOrder->work_order_no,
                    'work_title' => $workOrder->work_title,
                    'customer_name' => $workOrder->customer?->name,
                    'issue_date' => $workOrder->issue_date?->toDateString(),
                    'status' => $workOrder->status,
                    'total_amount' => (float) $workOrder->total_amount,
                    'sales_amount' => round((float) $workOrder->sales_amount, 2),
                    'other_income_amount' => round((float) $workOrder->other_income_amount, 2),
                    'purchase_amount' => round((float) $workOrder->purchase_amount, 2),
                    'expense_amount' => round((float) $workOrder->expense_amount, 2),
                    'total_cost' => round($cost, 2),
                    'profit_amount' => round($income - $cost, 2),
                ];
            });

        $totals = [];
        foreach (['total_amount', 'sales_amount', 'other_income_amount', 'purchase_amount', 'expense_amount', 'total_cost', 'profit_amount'] as $column) {
            $totals[$column] = round($rows->sum($column), 2);
        }

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'totals' => $totals,
        ];
    }

    /**
     * One work order's sales, purchases and income/expense entries in date
     * order, each as income or cost, with the profit or loss they leave.
     *
     * @return array{work_order: array<string, mixed>, from_date: ?string, to_date: ?string, rows: array<int, array<string, mixed>>, total_income: float, total_cost: float, profit_amount: float}
     */
    public function workOrderDetails(WorkOrder $workOrder, ?string $fromDate, ?string $toDate): array
    {
        $inRange = fn ($relation, string $column) => $relation
            ->when($fromDate, fn ($query) => $query->whereDate($column, '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate($column, '<=', $toDate));

        $sales = $inRange($workOrder->sales(), 'issue_date')
            ->with('customer:id,name')
            ->get()
            ->map(fn (Sale $sale) => [
                'date' => $sale->issue_date?->toDateString(),
                'type' => 'Sale',
                'reference' => $sale->invoice_number,
                'party_name' => $sale->customer?->name,
                'description' => $sale->description,
                'income' => (float) $sale->net_total,
                'cost' => 0.0,
            ]);

        $purchases = $inRange($workOrder->purchases(), 'purchase_date')
            ->with('supplier:id,name')
            ->get()
            ->map(fn (Purchase $purchase) => [
                'date' => $purchase->purchase_date?->toDateString(),
                'type' => 'Purchase',
                'reference' => $purchase->invoice_number,
                'party_name' => $purchase->supplier?->name,
                'description' => $purchase->description,
                'income' => 0.0,
                'cost' => (float) $purchase->net_total,
            ]);

        $entries = $inRange($workOrder->incomeExpenses(), 'transaction_date')
            ->with('account:id,name')
            ->get()
            ->map(fn (IncomeExpenseTransaction $entry) => [
                'date' => $entry->transaction_date?->toDateString(),
                'type' => $entry->type === 'income' ? 'Income' : 'Expense',
                'reference' => $entry->reference_no,
                'party_name' => $entry->account?->name,
                'description' => $entry->description,
                'income' => $entry->type === 'income' ? (float) $entry->amount : 0.0,
                'cost' => $entry->type === 'expense' ? (float) $entry->amount : 0.0,
            ]);

        $rows = $sales->concat($purchases)->concat($entries)->sortBy('date')->values();
        $totalIncome = round($rows->sum('income'), 2);
        $totalCost = round($rows->sum('cost'), 2);

        $workOrder->loadMissing('customer:id,name');

        return [
            'work_order' => [
                'id' => $workOrder->id,
                'work_order_no' => $workOrder->work_order_no,
                'work_title' => $workOrder->work_title,
                'customer_name' => $workOrder->customer?->name,
                'total_amount' => (float) $workOrder->total_amount,
                'status' => $workOrder->status,
            ],
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'total_income' => $totalIncome,
            'total_cost' => $totalCost,
            'profit_amount' => round($totalIncome - $totalCost, 2),
        ];
    }

    /**
     * Each customer's billing (debits), collection (credits) and due at the
     * end of every month or year in a date range, from the active customer
     * ledger entries. The due carries the opening balance and everything
     * before the range forward, as the customer statement does. Only periods
     * in which a customer had entries are listed.
     *
     * @param  array<int, int>  $customerIds
     * @return array{period: string, from_date: string, to_date: string, rows: array<int, array<string, mixed>>, total_billed: float, total_collected: float, total_due: float}
     */
    public function customerCollections(array $customerIds, string $period, string $fromDate, string $toDate): array
    {
        $customers = Customer::query()
            ->when($customerIds, fn ($query) => $query->whereIn('id', $customerIds))
            ->get(['id', 'name', 'opening_balance'])
            ->keyBy('id');

        $transactions = CustomerTransaction::query()
            ->where('status', true)
            ->whereIn('customer_id', $customers->keys())
            ->whereDate('transaction_date', '<=', $toDate);

        $broughtForward = (clone $transactions)
            ->whereDate('transaction_date', '<', $fromDate)
            ->groupBy('customer_id')
            ->selectRaw('customer_id, COALESCE(SUM(debit), 0) - COALESCE(SUM(credit), 0) as net')
            ->pluck('net', 'customer_id');

        $format = $period === 'yearly' ? 'Y' : 'Y-m';
        $due = $customers->map(fn (Customer $customer) => round((float) $customer->opening_balance + (float) ($broughtForward[$customer->id] ?? 0), 2));

        $rows = $transactions
            ->whereDate('transaction_date', '>=', $fromDate)
            ->orderBy('transaction_date')
            ->orderBy('id')
            ->get(['id', 'customer_id', 'transaction_date', 'debit', 'credit'])
            ->groupBy(fn (CustomerTransaction $row) => $row->transaction_date->format($format))
            ->flatMap(fn (Collection $periodRows, string $periodKey) => $periodRows
                ->groupBy('customer_id')
                ->map(function (Collection $customerRows, int $customerId) use ($periodKey, $customers, $due) {
                    $billed = round((float) $customerRows->sum('debit'), 2);
                    $collected = round((float) $customerRows->sum('credit'), 2);
                    $due[$customerId] = round($due[$customerId] + $billed - $collected, 2);

                    return [
                        'period' => $periodKey,
                        'customer_id' => $customerId,
                        'customer_name' => $customers[$customerId]->name,
                        'billed_amount' => $billed,
                        'collected_amount' => $collected,
                        'due_amount' => $due[$customerId],
                    ];
                })
                ->sortBy('customer_name')
                ->values())
            ->values();

        return [
            'period' => $period,
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'rows' => $rows->all(),
            'total_billed' => round($rows->sum('billed_amount'), 2),
            'total_collected' => round($rows->sum('collected_amount'), 2),
            'total_due' => round($due->sum(), 2),
        ];
    }

    /**
     * A supplier or customer ledger statement. `$increasingSide` is the
     * column (debit or credit) that raises the balance owed; the other one
     * is shown as paid.
     *
     * @param  Builder<SupplierTransaction>|Builder<CustomerTransaction>  $transactions
     * @param  callable(SupplierTransaction|CustomerTransaction): ?string  $partyName
     * @return array{from_date: ?string, to_date: ?string, previous_balance: float, rows: array<int, array<string, mixed>>, total_amount: float, total_paid: float, total_due: float}
     */
    private function partyStatement(Builder $transactions, float $opening, string $increasingSide, callable $partyName, ?string $fromDate, ?string $toDate): array
    {
        $decreasingSide = $increasingSide === 'debit' ? 'credit' : 'debit';
        $transactions->where('status', true);

        $broughtForward = $fromDate
            ? (clone $transactions)->whereDate('transaction_date', '<', $fromDate)
                ->selectRaw("COALESCE(SUM({$increasingSide}), 0) - COALESCE(SUM({$decreasingSide}), 0) as net")
                ->value('net')
            : 0;

        $previousBalance = round($opening + (float) $broughtForward, 2);
        $due = $previousBalance;

        $rows = $transactions
            ->when($fromDate, fn ($query) => $query->whereDate('transaction_date', '>=', $fromDate))
            ->when($toDate, fn ($query) => $query->whereDate('transaction_date', '<=', $toDate))
            ->orderBy('transaction_date')
            ->orderBy('id')
            ->get()
            ->map(function ($row) use (&$due, $increasingSide, $decreasingSide, $partyName) {
                $amount = (float) $row->{$increasingSide};
                $paid = (float) $row->{$decreasingSide};
                $due = round($due + $amount - $paid, 2);

                return [
                    'id' => $row->id,
                    'party_name' => $partyName($row),
                    'invoice_no' => $row->invoice_no,
                    'date' => $row->transaction_date?->toDateString(),
                    'transaction_type' => $row->transaction_type,
                    'notes' => $row->notes,
                    'amount' => $amount,
                    'paid' => $paid,
                    'due' => $due,
                ];
            });

        return [
            'from_date' => $fromDate,
            'to_date' => $toDate,
            'previous_balance' => $previousBalance,
            'rows' => $rows->all(),
            'total_amount' => round($rows->sum('amount'), 2),
            'total_paid' => round($rows->sum('paid'), 2),
            'total_due' => $due,
        ];
    }

    /**
     * Journal lines joined to their entry, so they can be filtered by date.
     */
    private function lines(): Builder
    {
        return AccountTransactionDetail::query()
            ->join('account_transactions', 'account_transactions.id', '=', 'account_transaction_details.account_transaction_id');
    }

    /**
     * Debit minus credit per account for the lines matching `$filter`.
     *
     * @param  callable(Builder): Builder  $filter
     * @return Collection<int, float>
     */
    private function netByAccount(callable $filter): Collection
    {
        return $filter($this->lines())
            ->groupBy('account_transaction_details.chart_of_account_id')
            ->selectRaw('account_transaction_details.chart_of_account_id as account_id, SUM(account_transaction_details.debit) - SUM(account_transaction_details.credit) as net')
            ->pluck('net', 'account_id')
            ->map(fn ($net) => round((float) $net, 2));
    }

    /**
     * Debit minus credit over every account of a type.
     */
    private function netOfType(int $accountTypeId, ?string $fromDate, ?string $toDate): float
    {
        $net = $this->lines()
            ->join('chart_of_accounts', 'chart_of_accounts.id', '=', 'account_transaction_details.chart_of_account_id')
            ->where('chart_of_accounts.account_type_id', $accountTypeId)
            ->when($fromDate, fn (Builder $query) => $query->where('account_transactions.date', '>=', $fromDate))
            ->when($toDate, fn (Builder $query) => $query->where('account_transactions.date', '<=', $toDate))
            ->selectRaw('COALESCE(SUM(account_transaction_details.debit), 0) - COALESCE(SUM(account_transaction_details.credit), 0) as net')
            ->value('net');

        return round((float) $net, 2);
    }

    /**
     * Split a net (debit minus credit) balance into debit and credit columns.
     *
     * @return array<string, float>
     */
    private function columns(float $net, string $prefix = ''): array
    {
        return [
            "{$prefix}debit" => max($net, 0),
            "{$prefix}credit" => $net < 0 ? abs($net) : 0.0,
        ];
    }

    private function side(float $balance): string
    {
        return $balance > 0 ? 'Dr' : 'Cr';
    }
}
